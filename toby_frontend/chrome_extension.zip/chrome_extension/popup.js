document.getElementById("openApp").addEventListener("click", () => {
    chrome.tabs.create({ url: "http://192.168.0.48:3002" }); // Replace with your React app's URL
  });
  