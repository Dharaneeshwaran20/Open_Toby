// background.js

// Listen for new tab creation
chrome.tabs.onCreated.addListener(function(tab) {
    // Redirect the new tab to the home page of your React app
    chrome.tabs.update(tab.id, { url: "http://192.168.0.48:3002" });
  });
  